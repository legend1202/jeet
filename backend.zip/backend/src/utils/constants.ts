export const Roles = ['ADMIN', 'FELLESRAAD', 'COMPANY', 'CLIENT'];
export const Gender = ['MAN', 'WOMEN'];
